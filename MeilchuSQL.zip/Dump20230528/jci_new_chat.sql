-- MySQL dump 10.13  Distrib 8.0.31, for macos12 (x86_64)
--
-- Host: 127.0.0.1    Database: jci
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `new_chat`
--

DROP TABLE IF EXISTS `new_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_chat` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `senderid` int(11) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `message` text,
  `room` int(11) DEFAULT NULL,
  PRIMARY KEY (`chat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_chat`
--

LOCK TABLES `new_chat` WRITE;
/*!40000 ALTER TABLE `new_chat` DISABLE KEYS */;
INSERT INTO `new_chat` VALUES (1,5,4,'asdasd','',NULL),(2,5,4,'asdasd','asdasdasd',NULL),(3,5,4,'asdasd','sdfsdfsdf',NULL),(4,5,4,'asdasd','dsfsdf',NULL),(5,5,4,'asdasd','Test',NULL),(6,3,2,'john123','',NULL),(7,3,2,'john123','test',NULL),(8,3,4,'asdasd','test',NULL),(9,3,2,'john123','asdasd',NULL),(10,3,2,'john123','',NULL),(11,3,2,'john123','test',NULL),(12,3,2,'john123','test',NULL),(13,3,2,'john123','',NULL),(14,3,2,'john123','test',67),(15,3,2,'john123','asd',67),(16,3,2,'john123','sadasd',67),(17,3,2,'john123','test',67),(18,3,2,'john123','test',67),(19,2,3,'elle123','hello',70),(20,3,2,'john123','hey',67),(21,3,2,'john123','test',67),(22,2,3,'elle123','test',70),(23,2,3,'elle123','test2',70),(24,3,2,'john123','test',67),(25,2,3,'elle123','',70),(26,2,3,'elle123','asd',70),(27,2,3,'elle123','test',70),(28,2,3,'elle123','fghfgh',70),(29,2,3,'elle123','test',70),(30,2,3,'elle123','How are you?',70),(31,3,2,'john123','I am well',67),(32,3,2,'john123','How are you?',67),(33,5,3,'elle123','hello',58),(34,3,5,'test','How are you?',72),(35,3,2,'john123','test',67),(36,2,3,'elle123','test',70),(37,3,2,'john123','test4',67),(38,2,3,'elle123','hi',70),(39,2,3,'elle123','hello',70),(40,3,2,'john123','how are you?',67),(41,2,3,'elle123','test',70),(42,3,2,'john123','How are you elle?',67),(43,2,3,'elle123','doing good. Thank you',70),(44,2,3,'elle123','hellow',70),(45,2,3,'elle123','hu!',70),(46,2,3,'elle123','test',70),(47,3,2,'john123','hello',67),(48,3,2,'john123','test',67),(49,3,2,'john123','test',67),(50,3,2,'john123','hey',67),(51,8,3,'elle123','hello',76),(52,3,1,'meil','how are you?',69),(53,8,3,'elle123','Doing good. Thank you',76);
/*!40000 ALTER TABLE `new_chat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-28 11:31:29
